var bananaImage, obstacleImage, obstaclesGroup, score;

function preload() {
  backImage = loadImage("jungle.jpg");
  player_running =
    loadAnimation("Monkey_01.jpg", "Monkey_02.jpg", "Monkey_03.jpg", "Monkey_04.jpg", "Monkey_05.jpg", "Monkey_06.jpg", "Monkey_07.jpg", "Monkey_08.jpg", "Monkey_09.jpg", "Monkey_10.jpg", );

  bananaImage = loadImage("Banana.png");
  obstacle_img = loadImage("stone.png");
  background = ("jungle.jpg")
  

}

function setup() {
  
  background(200,200);
  background.velocityX = (3);
  ground.visibility = false;
  monkey.scale = 0.5;
  
}

function draw() {
preload();
setup();
  if(foodGroup.isTouching(player)){
    score = score+1;
  }
  switch(score){
    case 10: player.scale=0.12;
                break;
    case 20: player.scale=0.14;
                break;
    case 30: player.scale=0.16;
                break;
    case 40: player.scale=0.18;
             break;
             default:break;
    if(obstacleGroup.isTouching(player)){
      player.scale=player.scale - 0.01;
    }
  }
  
  
  
  
  
}